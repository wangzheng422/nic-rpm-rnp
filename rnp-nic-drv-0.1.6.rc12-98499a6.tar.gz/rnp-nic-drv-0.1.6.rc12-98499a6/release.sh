#!/bin/bash

script_dir=$(dirname $(readlink -f $0))
proj_top=$(readlink -f "${script_dir}/")


version=$(grep 'define DRV_VERSION' $proj_top/rnp/rnp_main.c  | awk '{gsub("\"","",$3) ;print $3}')
echo "version from rnp/rnp_main.c: DRV_VERSION: $version "

git_commit=$(git rev-parse --short HEAD)
prefix="rnp-nic-drv-${version}-$git_commit"

out_file="$(readlink -f "${proj_top}/../${prefix}.tar.gz")"

cd $proj_top
git archive --format=tar.gz --prefix="${prefix}/" -o $out_file  HEAD $proj_top 
git tag $version


echo $out_file