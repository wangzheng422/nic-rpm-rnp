
net.ifnames=0 biosdevname=0

# ethtool
============
## show driver info 
ethtool -i rnp<x>

## no manage
nmcli dev set rnp00 managed no
nmcli dev set rnp10 managed no

## debugfs
mkdir /debugfs
mount -t debugfs none /debugfs
cd /debugfs/rnp/rnp010


## show driver private flags and theire states
ethtool --show-priv-flags rnp<x>

## enable/disable driver private feature flag
ethtool --set-priv-flags rnp<x>      

## Queries the stateless offload status
ethtool -k rnp<x>                    

## set the offload status
ethtool -K rnp<x> [rx on|off] [tx on|off]  
[sg on|off] [tso on|off] [lro on|off] 
[gro on|off] [gso on|off] [rxvlan on|off] 
[txvlan on|off] [ntuple on/off] [rxhash on/off] 
[rx-all on/off] [rx-fcs on/off]

## show channels (number of queues)
ethtool -l rnp<x>

## set channels  (number of queues)
ethtool -L rnp<x> [rx <N>] [tx <N>]

## obtains additional device statistics
ethtool -S rnp<x>

## irq affinity
cat /proc/interrupts |grep rnp10
echo fffe > /proc/irq/<N>/smp_affinity

## tx queue select mask
 method 1
    ethtool -L rnp<x> tx <N>
    echo XX >  /sys/module/rnp10/drivers/pci\:rnp10/module/parameters/tx_queue_mask

    ie: 
        let queue-3 do-tx 
            echo $(( 1<<2 )) >  /sys/module/rnp10/parameters/tx_queue_mask

        let queue-3 + queue-4  do-tx 
            echo $(( (1<<2) | (1<<3))) >  /sys/module/rnp10/parameters/tx_queue_mask
  methd 2 by tc 
    tc qdisc add dev rnp00 root handle 1: multiq
    tc filter add dev rnp00 parent 1: protocol ip prio 1 u32  match ip dst 1.2.3.8 action skbedit queue_mapping 0

    tc filter show dev rnp00
    tc filter del dev rnp00
  work-method
    ./tools/install_drv.sh
    # can only set when nic is down
    ethtool -L rnp00 tx 2 rx 2
    ./tools/ifconfig_rnp0.sh
    iperf3 -c 1.2.3.8
    ethtool -S rnp00

## VLAN
    LINK :https://developers.redhat.com/blog/2017/09/14/vlan-filter-support-on-bridge/
    1. open vlan offload
        sudo ethtool -K rnp00 rxvlan on
        sudo ethtool -K rnp00 txvlan on

    2. add vlan dev (this)
        ip link add link rnp00 name rnp00.3112 type vlan id 3112
        ifconfig rnp00.3112 192.168.30.100 netmask 255.255.255.0  up

    3. add vlan dev (peer)
        ip link add link p4p1 name p4p1.3112 type vlan id 3112
        ifconfig p4p1.3112 192.168.30.101 netmask 255.255.255.0 up

    4. test (this)
        ping 192.168.30.101

### VLAN active vid in vfs
    cat /sys/class/net/rnpvf00/active_vid
    echo "vid" >> /sys/class/net/rnpvf00/active_vid

### VLAN Filter
    1. ethtool -K rnp00 rx-vlan-filter off


## VXLAN (ndo_udp_tunnel_add)
    ethtool -K rnp00 tx-udp_tnl-segmentation

    # Enable inner packet checksums offload
    ethtool -K rnp00 tx-udp_tnl-csum-segmentation on

    ip link add vxlan0 type vxlan \
        id 42 \
        dstport 4789 \
        remote 1.2.3.8 \
        local 1.2.3.3 \
        dev rnp00

    ip -d link show vxlan0
    

## ntuple
    ethtool -K rnp00 ntuple on

    ## sip,dip to queue 4
        ethtool --config-ntuple flow-type tcp4 \
         src-ip 10.23.4.6 dst-ip 10.23.4.18 action 3

    ## dport=80 to queue2
       ethtool -U rnp00 flow-type tcp4 dst-port 80 action 2 

    ## ethtool --show-ntuple

## RSS
    ethtool -x rnp00
    ethtool -X rnp00 wight 6 2
    ethtool -n eth0 rx-flow-hash udp4
    ethtool -N eth0 rx-flow-hash udp4 sdfn

    ethtool -N eth0 flow-type ether dst 00:00:00:00:01:00 \
        m ff:ff:ff:ff:ff:ff src 00:00:00:00:20:00 m 00:00:00:00:00:00 \
        vlan 10 user-def 0x800000000 action 1 loc 5

## queue
    #set queue size
    ethtool -G rnp00 rx 500 tx 400

    #get current queue size
    ethtool -g

## TSO
    ethtool -K rnp00 tso on

## VF 

### VF vlan
    ip link set rnp00 vf 1 vlan 32 qos 2

### VF mac-addr
    ip link set rnp00 vf 1 mac 00:4e:31:30:44:80

    show ip link show rnp00

### VF TX rate limit
     // set vf0 rate to 1000Mbps(peer queue)
     ip link set rnp0 vf 1 rate 1000

## PUASE Frame
    ethtool -A rnp00 rx on
    ethtool -A rnp00 tx on
# multicast
    ip maddr add  

    ie:
        server: (192.168.31.99)
         socat UDP4-RECVFROM:6666,ip-add-membership=224.1.0.1:192.168.31.99,fork EXEC:"echo helloword"

        client(192.168.31.153):
            ip maddr add 
           echo aa | socat STDIO UDP4-DATAGRAM:224.1.0.1:6666,range=192.168.31.0/24

# macvlan
     ip link add macvlan1 link rnp00 type macvlan mode bridge
     ip link add macvlan2 link rnp00 type macvlan mode bridge
     ip netns add net1
     ip netns add net2
     ip link set macvlan1 netns net1
     ip link set macvlan2 netns net2


# vm hot-
    pci-detach vf from vm

