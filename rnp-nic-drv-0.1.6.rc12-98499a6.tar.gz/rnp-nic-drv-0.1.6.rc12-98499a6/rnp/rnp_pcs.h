#ifndef _RNP_PCS_H_
#define _RNP_PCS_H_

extern struct rnp_pcs_operations pcs_ops_generic;

#endif
