#!/bin/bash

up_cnt=0
down_cnt=0
for  d in $(ls /sys/bus/pci/drivers/rnpvf)
do
	net_dir="/sys/bus/pci/drivers/rnpvf/$d/net/"
	if [ -e $net_dir ];then
		for net in $(ls $net_dir);do
			up=$(cat $net_dir/$net/carrier 2>/dev/null)
			if [[ $up -eq 1 ]];then
				echo -e "$net\t up"
				up_cnt=$(( $up_cnt + 1 ))
			else
				echo -e "$net\t down!"
				down_cnt=$(( $down_cnt + 1 ))
			fi
		done
	fi
done


echo
echo "  up_cnt:$up_cnt  down_cnt:$down_cnt "
echo
