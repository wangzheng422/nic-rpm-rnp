#!/bin/sh

ethtool -K rnpvf00 tx-udp_tnl-segmentation on
ethtool -K rnpvf00 tx-udp_tnl-csum-segmentation on

ip link add vxlan0 type vxlan \
        id 42 \
        dstport 4789 \
        remote 1.2.3.8 \
        local 1.2.3.11 \
        dev rnpvf00

ifconfig vxlan0 2.3.4.11 netmask 255.255.255.0 up

ip -d link show vxlan0
