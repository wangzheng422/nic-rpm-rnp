#!/bin/sh

cwd=$(dirname $(readlink -f $0))/../

source $cwd/regfun.env

ring=${1:-1}

echo -e "\n== VF_MSIX_TABLE== "
bar4_r32 $((0xa0000 ))  8

echo -e "\n== PF2VF MBX VECTOR == "
bar4_r32 $((0xa5000 ))  8

echo -e "\n== VF2PF MBX VECTOR == "
bar4_r32 $((0xa5100 ))  4

echo -e "\n== PF_VF_SHM== "
bar4_r32 $((0xa6000 + 64*$ring )) 2
echo -e "\n== PF_VF_SHM_DATA"
bar4_r32 $((0xa6008 + 64*$ring )) 14

echo ""

echo -e "VF2PF_MBX_CTRL1\t: $(bar4_r32 $((0xa7000 + 4*$ring)))"
echo -e "PF2VF_MBX_CTRL1\t: $(bar4_r32 $((0xa7100 + 4*$ring)))"
echo -e "PF2VF_MBX_MASK_L: $(bar4_r32 $((0xa7200 + 4*$ring)))"
echo -e "PF2VF_MBX_MASK_H: $(bar4_r32 $((0xa7300 + 4*$ring)))"


