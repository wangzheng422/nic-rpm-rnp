#!/bin/sh

cwd=$(dirname $(readlink -f $0))/../

ring=${1:-1}

source $cwd/regfun.env

echo "VF2PF_MBX_CTRL1"
bar4_w32 $((0xa7000 + 4*$ring)) 0x1
