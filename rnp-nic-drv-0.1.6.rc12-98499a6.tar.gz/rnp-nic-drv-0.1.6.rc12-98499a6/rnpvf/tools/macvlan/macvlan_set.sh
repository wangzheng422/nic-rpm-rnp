#!/bin/sh

ip link add macvlan1 link rnpvf00 type macvlan mode bridge
ip link add macvlan1 link rnpvf00 type macvlan mode bridge

ip addr add 3.4.5.11/24 dev macvlan1
ip link set macvlan1 up
