#!/bin/bash

IP=${1:-70}

if [ "$1" == "del" ];then
    ethtool -K rnpvf00 rxvlan off
    ethtool -K rnpvf00 txvlan off
    exit 0
fi

##ethtool -L rnpvf00 combined 1

ethtool -K rnpvf00 rxvlan on
ethtool -K rnpvf00 txvlan on

VLAN_DEV=vlan.4

ip link add link rnpvf00 name $VLAN_DEV type vlan id 4
ifconfig  $VLAN_DEV 192.168.30.$IP netmask 255.255.255.0 up

 ip -d link show  $VLAN_DEV
