#!/bin/sh

cwd=$(dirname $(readlink -f $0))

source $cwd/regfun.env

reg=${1:-0}
shift

bar0_r32 $(( $reg )) $@

