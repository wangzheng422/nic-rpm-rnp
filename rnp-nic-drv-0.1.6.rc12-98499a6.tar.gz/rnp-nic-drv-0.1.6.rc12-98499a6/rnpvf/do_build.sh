#!/bin/bash

cwd=$(dirname $(readlink -f $0))
cd $cwd

CFLAGS=""
NIC_OFF=0x0
QUEUES_PEER_FUN=2
FPGA=1
PV=1

Usage=" $0  [help] [hi_dma]  \n \
    [rx-debug] [tx-debug] [hw_debug] [debug] [skbdump] [io] \n \
    [pv=xx] [offloading]   \n \
    [poll] [no-tx-irq] [no-rx-irq] [irq-debug] \n \
    [queue=N] [nic=0xN]  \n \
    [no-pf0] [no-pf1] [2pf] [bar4]\
    [mbx-debug] \
    <target> \n \


target: \n\t n10-vf | n10-vf-fix"

for arg in "$@"
do
    shift
    [[ $arg == *help ]]              && echo -e "$Usage"                               && exit 0
    [[ $arg == -h ]]                 && echo "$Usage"                                  && exit 0
    [[ $arg == queue* ]]             && IN_QUEUES_PEER_FUN=${arg//queue=/}                && continue
    [[ $arg == nic* ]]               && NIC_OFF=${arg//nic=/}                          && continue
    [[ $arg == asic ]]               && FPGA=0                                          && continue

    # remove debug/io/no-tx-irq args
    [[ $arg == irq-debug ]]          && CFLAGS+=" -DIRQ_DEBUG=1 "                            && continue
    [[ $arg == debug ]]              && CFLAGS+=" -DDEBUG=1 "                            && continue
    [[ $arg == hw-debug ]]           && CFLAGS+=" -DHW_DEBUG=1 "                            && continue
    [[ $arg == io ]]                 && CFLAGS+=" -DIO_PRINT=1 "                         && continue
    [[ $arg == no-tx-irq ]]          && CFLAGS+=" -DDISABLE_TX_IRQ=1 "                   && continue
    [[ $arg == no-rx-irq ]]          && CFLAGS+=" -DDISABLE_RX_IRQ=1 "                   && continue
    [[ $arg == poll* ]]              && CFLAGS+=" -DDISABLE_TX_IRQ=1 -DDISABLE_RX_IRQ=1  " && continue
    [[ $arg == skbdump ]]            && CFLAGS+=" -DSKB_DUMP=1  "                        && continue
    [[ $arg == hi_dma ]]             && CFLAGS+=" -DENABLE_64BIT_DMA  "                       && continue
    [[ $arg == offload* ]]           && CFLAGS+=" -DHW_OFFLOADING  "                      && continue
    [[ $arg == tx-debug* ]]          && CFLAGS+=" -DCONFIG_RNP_TX_DEBUG=1  "                        && continue
    [[ $arg == rx-debug* ]]          && CFLAGS+=" -DCONFIG_RNP_RX_DEBUG=1  "                        && continue
    [[ $arg == mbx-debug* ]]          && CFLAGS+=" -DCONFIG_RNP_MBX_DEBUG=1  "                        && continue
    [[ $arg == no-pf1 ]]             && CFLAGS+=" -DCONFIG_RNP_DISABLE_PF1=1  "                        && continue
    [[ $arg == no-dma2 ]]             && CFLAGS+=" -DCONFIG_RNP_DISABLE_DMA2=1  "                        && continue
    [[ $arg == no-dma1 ]]             && CFLAGS+=" -DCONFIG_RNP_DISABLE_DMA1=1  "                        && continue
    [[ $arg == no-pf0 ]]             && CFLAGS+=" -DCONFIG_RNP_DISABLE_PF0=1  "                        && continue
    [[ $arg == 2pf ]]         && CFLAGS+=" -DHAS_2PF  "                        && continue
    [[ $arg == iov ]]      && CFLAGS+=" -DCONFIG_RNP_IOV=1  "                        && continue
    [[ $arg == msg_probe ]]      && CFLAGS+=" -DMSG_PROBE_ENABLE=1  "                        && continue
    [[ $arg == msg_ifup ]]      && CFLAGS+=" -DMSG_IFUP_ENABLE=1  "                        && continue
    [[ $arg == msg_ifdown ]]      && CFLAGS+=" -DMSG_IFDOWN_ENABLE=1  "                        && continue
    [[ $arg == vebug ]]      && CFLAGS+=" -DRNP_IOV_VEB_BUG_NOT_FIXED=1  "                        && continue

    # save other-arg
    set -- "$@" "$arg"
done
set -- "$@"
TARGET=${1:-n10-vf-fix}
shift
ARGS="$@"

[[ $TARGET == n10-vf ]] && NIC_OFF=0x0   && QUEUES_PEER_FUN=2 && FPGA=1 && CFLAGS+=" -DUV440_2PF -DNIC_BAR4 -DHAS_2PF "
[[ $TARGET == n10-vf-fix ]] && NIC_OFF=0x0   && QUEUES_PEER_FUN=2 && FPGA=1 && CFLAGS+=" -DFIX_VF_BUG -DUV440_2PF -DNIC_BAR4 -DHAS_2PF "

if [[ -z "$IN_QUEUES_PEER_FUN" ]];then
IN_QUEUES_PEER_FUN=$QUEUES_PEER_FUN
fi


buildargs="-DNIC_BASE_OFF=$NIC_OFF -DPORT_ASSIGN_VERSION=$PV -DQUEUES_PEER_FUN=$IN_QUEUES_PEER_FUN  $CMDLINE $ARGS $CFLAGS  "
if [ $FPGA -ne "0" ];then
    buildargs+=" -DCONFIG_RNP_FPGA " 
fi
echo "build: $TARGET, $buildargs "

echo "EXTRA_CFLAGS += $buildargs " > .define.mk

make  clean
export SWD=$cwd
make -j2 
