#!/bin/bash

insmod rnpvf.ko

nmcli dev set rnpvf00 managed no 
nmcli dev set rnpvf10 managed no 
