#ifndef VERSION_H
#define VERSION_H
#define GIT_COMMIT " 42f3895"
#endif
