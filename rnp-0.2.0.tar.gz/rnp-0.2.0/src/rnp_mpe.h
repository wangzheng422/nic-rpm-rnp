#ifndef RNP_MPE_H
#define RNP_MPE_H

#include "rnp.h"

int rpu_mpe_start(struct rnp_adapter *adapter);
void rpu_mpe_stop(struct rnp_adapter *adapter);

#endif // RNP_MPE_H