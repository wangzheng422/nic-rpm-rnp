#!/bin/bash

./do_build.sh 440-0930-2pf vebug  $@

